# 17I2980
University of Nebraska at Omaha, CSCI 2980, Graphics in Java Spring 2017

# Course Notes
You can see the course notes (live) [here](https://1drv.ms/o/s!AmCUMqdaJyCSgb91UAJx9VDurhosRw).

# Public Domain Images
Concerned about copyright? You should be. Here's a list of resources that you can use without worrying.

My [flickr page](https://www.flickr.com/photos/bricksphd/) is all CC0.

Wikipedia has a great list resources [here](https://en.wikipedia.org/wiki/Wikipedia:Public_domain_image_resources).


