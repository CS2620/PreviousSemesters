// standard global variables
var scene, camera, renderer, textureLoader;

var imagePlane = null;

var renderedOnce = false;

// boot THREE.JS
function init(shaders) {
  // SCENE
  scene = new THREE.Scene();
  textureLoader = new THREE.TextureLoader();

  // CAMERA
  camera = new THREE.PerspectiveCamera(
    45 /* View Angle */,
    app.img.width / app.img.height, /*Aspect Ratio*/
    .1 /*Near*/, 100/*Far*/);

  scene.add(camera);

  camera.position.set(0, 0, 1);
  camera.lookAt(scene.position);//0,0,0

  renderer = new THREE.WebGLRenderer({
    antialias: true,
    //alpha: true,
    //canvas: app.endCanvas
  });
  console.log(renderer.capabilities)
  var container = document.querySelector("#endCol");
  container.appendChild(renderer.domElement);
  renderer.domElement.style.maxWidth = "640px";
  renderer.domElement.style.width = "100%"
  
  imagePlane = buildPlane(shaders);
  scene.add(imagePlane);

  // Start animation
  animate();
}

function buildPlane(shaders) {
  var g = new THREE.PlaneGeometry(app.img.width / app.img.height, 1);
  var imagePlane = textureLoader.load(app.img.src);
  //imagePlane.magFilter = THREE.NearestFilter;

  var mat = new THREE.ShaderMaterial({
    uniforms: THREE.UniformsUtils.merge([
      THREE.UniformsLib['lights'],
      {
        r_percent: { type: 'f', value: 1.0 },
        g_percent: { type: 'f', value: 1.0 },
        b_percent: { type: 'f', value: 1.0 },
        textureSampler: { type: 't', value: null }
      }
    ]),
    vertexShader: shaders[1],
    fragmentShader: shaders[0]
  });
  mat.uniforms.textureSampler.value = imagePlane;

  var obj = new THREE.Mesh(g, mat);
  return obj;
}

function animate() {
  renderer.setSize(renderer.domElement.parentElement.clientWidth, renderer.domElement.parentElement.clientWidth* app.img.height / app.img.width, false);
  
  let uniforms = imagePlane.material.uniforms;

  uniforms.r_percent.value = app.r_percent;
  uniforms.g_percent.value = app.g_percent;
  uniforms.b_percent.value = app.b_percent;

  // Render scene
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}